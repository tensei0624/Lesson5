Rails.application.routes.draw do
  root to: 'bookers#top'

  get 'bookers/books' => 'bookers#index'

  post 'bookers/books' => 'bookers#create'

  get 'bookers/books/:id' => 'bookers#show', as: 'show_bookers'

  get 'bookers/books/:id/edit' => 'bookers#edit', as: 'edit_bookers'

  patch 'bookers/books/:id' => 'bookers#update', as: 'update_bookers'

  delete 'bookers/books/:id' => 'bookers#destroy', as: 'destroy_bookers'

end