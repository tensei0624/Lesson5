class BookersController < ApplicationController
  def index
    @books = Book.all
    @book = Book.new
  end

  def show
    @book = Book.find(params[:id])
  end

  def edit
    @book = Book.find(params[:id])
  end

  def create
    @book = Book.new(book_params)
    if @book.save
      flash[:notice] = 'Book was successfully created.'
     redirect_to show_bookers_path(@book.id)
    else 
      @books = Book.all
      render :index
    end
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
      flash[:notice] = 'Book was successfully updated.'
    redirect_to show_bookers_path(@book.id)
    else
      render :edit
    end
  end

  def destroy
    book = Book.find(params[:id])
    if book.delete
      flash[:notice] = 'Book was successfully destroyed.'
     redirect_to bookers_books_path
    else 
     redirect_to bookers_books_path
    end
  end

  private
  def book_params
    params.require(:book).permit(:title, :body)
  end
end

